<?php
require '../config/db.php';
$title = 'Add Package'; $base = '../';
$errors = [];
$name = $price = $desc = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['package_name'] ?? '');
    $price = trim($_POST['package_price'] ?? '');
    $desc  = trim($_POST['package_description'] ?? '');

    if ($name === '') $errors[] = 'Package name is required.';
    if ($price === '' || !is_numeric($price) || $price < 0) $errors[] = 'Enter a valid price.';

    if (!$errors) {
        $stmt = $pdo->prepare('INSERT INTO packages (package_name, package_price, package_description) VALUES (:n, :p, :d)');
        $stmt->execute([':n' => $name, ':p' => $price, ':d' => $desc]);
        flash('Package "' . $name . '" was added.');
        header('Location: index.php'); exit;
    }
}
require '../includes/header.php';
?>
<h1>Add Package</h1>
<?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
<form method="post" class="form">
  <label>Package Name <input name="package_name" value="<?= e($name) ?>" required></label>
  <label>Price (&#8369;) <input name="package_price" type="number" step="0.01" min="0" value="<?= e($price) ?>" required></label>
  <label>Description <input name="package_description" value="<?= e($desc) ?>" maxlength="255"></label>
  <div><button class="btn" type="submit">Save Package</button> <a class="btn ghost" href="index.php">Cancel</a></div>
</form>
<?php require '../includes/footer.php'; ?>

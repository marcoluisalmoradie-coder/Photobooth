<?php
require '../config/db.php';
$title = 'Delete Package'; $base = '../';
$id = (int)($_GET['id'] ?? $_POST['package_id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT p.*, (SELECT COUNT(*) FROM bookings b WHERE b.package_id = p.package_id) AS total_bookings
     FROM packages p WHERE p.package_id = :id');
$stmt->execute([':id' => $id]);
$pkg = $stmt->fetch();
if (!$pkg) { flash('Package not found.', 'error'); header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $del = $pdo->prepare('DELETE FROM packages WHERE package_id = :id');
        $del->execute([':id' => $id]);
        flash('Package "' . $pkg['package_name'] . '" was deleted.');
    } catch (PDOException $e) {
        // ON DELETE RESTRICT: MySQL error 1451 when bookings still reference this package
        if (($e->errorInfo[1] ?? 0) == 1451 || $e->getCode() === '23000') {
            flash('Cannot delete: this package still has bookings. Delete those bookings first.', 'error');
        } else {
            flash('Delete failed: ' . $e->getMessage(), 'error');
        }
    }
    header('Location: index.php'); exit;
}
require '../includes/header.php';
?>
<h1>Delete Package</h1>
<?php if ($pkg['total_bookings'] > 0): ?>
  <div class="alert error">This package has <strong><?= (int)$pkg['total_bookings'] ?>
</strong> booking(s). Because of <code>ON DELETE RESTRICT</code>, delete or reassign those bookings first.</div>
<?php endif; ?>
<div class="card">
  <p>Are you sure you want to delete <strong><?= e($pkg['package_name']) ?></strong> (&#8369;<?= number_format($pkg['package_price'], 2) ?>)?</p>
  <form method="post">
    <input type="hidden" name="package_id" value="<?= (int)$id ?>">
    <button class="btn danger" type="submit">Yes, Delete</button>
    <a class="btn ghost" href="index.php">Cancel</a>
  </form>
</div>
<?php require '../includes/footer.php'; ?>

<?php
require '../config/db.php';
$title = 'Packages'; $base = '../';
require '../includes/header.php';
$rows = $pdo->query(
    'SELECT p.*, COUNT(b.booking_id) AS total_bookings
     FROM packages p LEFT JOIN bookings b ON b.package_id = p.package_id
     GROUP BY p.package_id ORDER BY p.package_id'
)->fetchAll();
?>
<div class="head"><h1>Packages</h1>
  <a class="btn" href="create.php">+ Add Package</a></div>
<table>
  <thead><tr><th>ID</th><th>Name</th><th>Price</th><th>Description</th><th>Bookings</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= (int)$r['package_id'] ?></td>
      <td><?= e($r['package_name']) ?></td>
      <td>&#8369;<?= number_format($r['package_price'], 2) ?></td>
      <td><?= e($r['package_description']) ?></td>
      <td><?= (int)$r['total_bookings'] ?></td>
      <td class="actions">
        <a class="btn small" href="edit.php?id=<?= (int)$r['package_id'] ?>">Edit</a>
        <a class="btn small danger" href="delete.php?id=<?= (int)$r['package_id'] ?>">Delete</a>
      </td>
    </tr>
  <?php endforeach; if (!$rows): ?>
    <tr><td colspan="6" class="empty">No packages yet. Click "Add Package".</td></tr>
  <?php endif; ?>
  </tbody>
</table>
<?php require '../includes/footer.php'; ?>

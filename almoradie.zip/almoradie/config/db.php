<?php
require_once __DIR__ . '/../includes/functions.php';

// PDO connection to MySQL/MariaDB (XAMPP defaults)
$host    = 'localhost';
$port    = 3306;
$dbname  = 'photobooth_db';
$user    = 'root';
$pass    = '';          // XAMPP default is a blank password

try {
    $pdo = new PDO(
        "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die('Database connection failed: ' . htmlspecialchars($e->getMessage()) .
        '<br>Did you import database.sql in phpMyAdmin?');
}

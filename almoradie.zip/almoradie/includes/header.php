<?php
// $base = path prefix to project root ('' or '../'), $title = page title
$base  = $base  ?? '';
$title = $title ?? 'FlashFrame';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | FlashFrame Photobooth</title>
<link rel="stylesheet" href="<?= $base ?>assets/css/style.css">
</head>
<body>
<header class="topbar">
  <div class="brand">&#128247; FlashFrame <span>Photobooth System</span></div>
  <nav>
    <a href="<?= $base ?>index.php">Dashboard</a>
    <a href="<?= $base ?>packages/index.php">Packages</a>
    <a href="<?= $base ?>bookings/index.php">Bookings</a>
  </nav>
</header>
<main class="container">
<?php flash_show(); ?>

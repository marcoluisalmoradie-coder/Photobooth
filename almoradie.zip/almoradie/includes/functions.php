<?php
// Helper functions shared by every page (loaded by config/db.php)
if (session_status() === PHP_SESSION_NONE) session_start();

function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// flash('message', 'success|error') stores a message; flash_show() prints it once
function flash($msg, $type = 'success') { $_SESSION['flash'] = [$msg, $type]; }
function flash_show() {
    if (!empty($_SESSION['flash'])) {
        [$m, $t] = $_SESSION['flash']; unset($_SESSION['flash']);
        echo '<div class="alert ' . e($t) . '">' . e($m) . '</div>';
    }
}

</main>
<footer class="footer">FlashFrame Photobooth System &middot; One Package &rarr; Many Bookings</footer>
</body>
</html>

CREATE DATABASE photobooth_db;
USE photobooth_db;

-- PARENT TABLE
CREATE TABLE packages (
    package_id INT AUTO_INCREMENT PRIMARY KEY,
    package_name VARCHAR(100) NOT NULL,
    package_price DECIMAL(10,2) NOT NULL,
    package_description VARCHAR(255)
);

-- CHILD TABLE
CREATE TABLE IF NOT EXISTS bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    event_date DATE NOT NULL,
    package_id INT NOT NULL,

    FOREIGN KEY (package_id)
    REFERENCES packages(package_id)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
);


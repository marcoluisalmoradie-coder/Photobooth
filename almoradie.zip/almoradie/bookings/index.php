<?php
require '../config/db.php';
$title = 'Bookings'; $base = '../';
require '../includes/header.php';
$rows = $pdo->query(
    'SELECT b.*, p.package_name FROM bookings b
     JOIN packages p ON p.package_id = b.package_id
     ORDER BY b.event_date, b.booking_id'
)->fetchAll();
?>
<div class="head"><h1>Bookings</h1>
  <a class="btn" href="create.php">+ Add Booking</a></div>
<table>
  <thead><tr><th>ID</th><th>Customer</th><th>Event</th><th>Date</th><th>Package</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= (int)$r['booking_id'] ?></td>
      <td><?= e($r['customer_name']) ?></td>
      <td><?= e($r['event_type']) ?></td>
      <td><?= e($r['event_date']) ?></td>
      <td><?= e($r['package_name']) ?></td>
      <td class="actions">
        <a class="btn small" href="edit.php?id=<?= (int)$r['booking_id'] ?>">Edit</a>
        <a class="btn small danger" href="delete.php?id=<?= (int)$r['booking_id'] ?>">Delete</a>
      </td>
    </tr>
  <?php endforeach; if (!$rows): ?>
    <tr><td colspan="6" class="empty">No bookings yet. Click "Add Booking".</td></tr>
  <?php endif; ?>
  </tbody>
</table>
<?php require '../includes/footer.php'; ?>
<?php
require '../config/db.php';
require '../includes/booking_validate.php';
$title = 'Edit Booking'; $base = '../';
$id = (int)($_GET['id'] ?? $_POST['booking_id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM bookings WHERE booking_id = :id');
$stmt->execute([':id' => $id]);
$b = $stmt->fetch();
if (!$b) { flash('Booking not found.', 'error'); header('Location: index.php'); exit; }

$packages = $pdo->query('SELECT package_id, package_name, package_price FROM packages ORDER BY package_name')->fetchAll();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    [$b, $errors] = read_booking($pdo);
    if (!$errors) {
        $up = $pdo->prepare('UPDATE bookings SET customer_name = :c, event_type = :t, event_date = :d, package_id = :p WHERE booking_id = :id');
        $up->execute([':c' => $b['customer_name'], ':t' => $b['event_type'], ':d' => $b['event_date'], ':p' => $b['package_id'], ':id' => $id]);
        flash('Booking #' . $id . ' was updated.');
        header('Location: index.php'); exit;
    }
}
require '../includes/header.php';
?>
<h1>Edit Booking #<?= (int)$id ?></h1>
<?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
<?php $button = 'Update Booking'; require '../includes/booking_form.php'; ?>
<?php require '../includes/footer.php'; ?>

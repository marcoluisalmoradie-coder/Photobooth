<?php
require '../config/db.php';
require '../includes/booking_validate.php';
$title = 'Add Booking'; $base = '../';
$packages = $pdo->query('SELECT package_id, package_name, package_price FROM packages ORDER BY package_name')->fetchAll();
$b = ['customer_name' => '', 'event_type' => '', 'event_date' => '', 'package_id' => (int)($_GET['package_id'] ?? 0)];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    [$b, $errors] = read_booking($pdo);
    if (!$errors) {
        $stmt = $pdo->prepare('INSERT INTO bookings (customer_name, event_type, event_date, package_id) VALUES (:c, :t, :d, :p)');
        $stmt->execute([':c' => $b['customer_name'], ':t' => $b['event_type'], ':d' => $b['event_date'], ':p' => $b['package_id']]);
        flash('Booking for "' . $b['customer_name'] . '" was added.');
        header('Location: index.php'); exit;
    }
}
require '../includes/header.php';
?>
<h1>Add Booking</h1>
<?php if (!$packages): ?>
  <div class="alert error">You need at least one package first. <a href="../packages/create.php">Add a package</a>.</div>
<?php else: ?>
  <?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
  <?php $button = 'Save Booking'; require '../includes/booking_form.php'; ?>
<?php endif; ?>
<?php require '../includes/footer.php'; ?>
